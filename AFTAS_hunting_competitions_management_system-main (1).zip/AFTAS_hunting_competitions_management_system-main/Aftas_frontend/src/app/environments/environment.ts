export const env = {
    production: false,
    api: 'http://localhost:8081',
    key: 'LjDwDpRX0kD51quxVNggfpKbdLu12tLs'
}
