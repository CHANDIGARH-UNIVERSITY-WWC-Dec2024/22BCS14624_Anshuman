export const env = {
    production: true,
    api: 'http://localhost:8081',
    key: 'LjDwDpRX0kD51quxVNggfpKbdLu12tLs'
}
