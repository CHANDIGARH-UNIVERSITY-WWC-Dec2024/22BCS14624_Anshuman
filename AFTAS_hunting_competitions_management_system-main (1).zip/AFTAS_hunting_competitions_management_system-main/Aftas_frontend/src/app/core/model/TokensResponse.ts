export interface TokensResponse {
    accessToken: string;
    refreshToken: string;
}