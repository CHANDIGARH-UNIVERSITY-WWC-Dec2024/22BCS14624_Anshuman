export interface Member {
   
    number: string,
    first_name: string,
    last_name: string,
    nationality: string,
    identity_document_type: string,
    identity_number: string
    is_activated: boolean,
}