export interface UserResponseInfo {
    number: number;
    firstName: string;
    lastName: string;
    password: string;
    nationality: string;
    identityDocumentType: string;
    identityNumber: string;
    role: string;

}