export interface LevelResp {
    id: number,
    code: string,
    points: number,
    description: string
}