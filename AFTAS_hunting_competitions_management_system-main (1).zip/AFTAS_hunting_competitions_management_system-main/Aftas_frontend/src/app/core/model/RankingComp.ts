import { Member } from "./Member";

export interface RankingComp{
        member: Member,
        rank: number,
        points: number,

}