package com.aftas_backend.security.utils.enums;

public enum TokenType {
    ACCESS_TOKEN, UNKNOWN, REFRESH_TOKEN
}
