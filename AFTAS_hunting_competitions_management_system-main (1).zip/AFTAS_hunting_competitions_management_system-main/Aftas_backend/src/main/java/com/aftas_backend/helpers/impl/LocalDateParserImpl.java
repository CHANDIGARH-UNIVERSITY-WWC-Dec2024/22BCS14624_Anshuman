package com.aftas_backend.helpers.impl;

import com.aftas_backend.helpers.LocalDateParser;

import java.time.LocalDate;

public class LocalDateParserImpl implements LocalDateParser {
    public LocalDate parse(String date) {
        return null;
    }

}
