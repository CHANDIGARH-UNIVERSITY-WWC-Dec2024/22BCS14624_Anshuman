package com.aftas_backend.security.utils.enums;

public enum EndPointType {
    REFRESH, AUTH, ACCESS
}
