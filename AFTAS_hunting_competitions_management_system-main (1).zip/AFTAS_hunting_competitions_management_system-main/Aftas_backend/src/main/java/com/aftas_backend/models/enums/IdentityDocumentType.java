package com.aftas_backend.models.enums;

public enum IdentityDocumentType {
    CIN,
    PASSPORT,
    PERMIT,
    RESIDENCE_CARD,
}
