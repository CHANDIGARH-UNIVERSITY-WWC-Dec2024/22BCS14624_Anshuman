package com.aftas_backend.helpers;

import java.time.LocalDate;

public interface LocalDateParser {
    LocalDate parse(String date);
}
