package com.aftas_backend.models.enums;

public enum Roles {
    MANAGER, JURY , ADHERENT,
}
